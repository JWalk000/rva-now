import { events, neighborhoods, vibes, lists } from '../../packages/shared/src/data.js';
import { filterEvents, personalize } from '../../packages/shared/src/helpers.js';

const state = {
  prefs: {
    neighborhoods: ["The Fan", "Scott's Addition"],
    vibes: ["Food & Drink", "Live Music", "Markets"]
  },
  filters: { neighborhood: '', vibe: '', freeOnly: false },
  view: 'list',
  saved: JSON.parse(localStorage.getItem('rva-now-saved') || '[]')
};

const $ = (id) => document.getElementById(id);
const listView = $('list-view');
const mapView = $('map-view');

$('event-count').textContent = String(events.length);

function renderChips(containerId, values, selected, onToggle) {
  const container = $(containerId);
  container.innerHTML = '';
  values.forEach((value) => {
    const chip = document.createElement('button');
    chip.className = `chip ${selected.includes(value) ? 'active' : ''}`;
    chip.textContent = value;
    chip.onclick = () => onToggle(value);
    container.appendChild(chip);
  });
}

function renderSelectOptions() {
  const neighborhoodSelect = $('neighborhood-filter');
  const vibeSelect = $('vibe-filter');
  neighborhoods.forEach((n) => {
    const option = document.createElement('option');
    option.value = n;
    option.textContent = n;
    neighborhoodSelect.appendChild(option);
  });
  vibes.forEach((v) => {
    const option = document.createElement('option');
    option.value = v;
    option.textContent = v;
    vibeSelect.appendChild(option);
  });
}

function saveEvent(id) {
  state.saved = state.saved.includes(id) ? state.saved.filter((x) => x !== id) : [...state.saved, id];
  localStorage.setItem('rva-now-saved', JSON.stringify(state.saved));
  renderSaved();
  renderEvents();
}

function eventCard(event) {
  const active = state.saved.includes(event.id);
  return `
    <article class="event-card">
      <div class="badges">
        ${event.featured ? '<span class="badge">Featured</span>' : ''}
        ${event.hiddenGem ? '<span class="badge">Hidden Gem</span>' : ''}
        <span class="badge">${event.neighborhood}</span>
      </div>
      <h3>${event.title}</h3>
      <p class="small muted">${event.description}</p>
      <div class="event-meta">
        <span>${event.day} · ${event.time}</span>
        <span>${event.venue}</span>
        <span>${event.price} · ${event.source}</span>
      </div>
      <div class="badges">${event.vibe.map((v) => `<span class="badge">${v}</span>`).join('')}</div>
      <button class="button ${active ? 'primary' : 'ghost'}" data-save="${event.id}">${active ? 'Saved' : 'Save event'}</button>
    </article>
  `;
}

function renderEvents() {
  const personalized = personalize(events, state.prefs);
  const filtered = filterEvents(personalized, state.filters);
  listView.innerHTML = filtered.map(eventCard).join('');
  mapView.innerHTML = filtered.map((event) => `
    <article class="map-card">
      <strong>${event.neighborhood}</strong>
      <h3>${event.title}</h3>
      <p class="small muted">${event.day} · ${event.time}</p>
      <p class="small muted">${event.venue}</p>
    </article>
  `).join('');

  document.querySelectorAll('[data-save]').forEach((button) => {
    button.onclick = () => saveEvent(button.dataset.save);
  });
}

function renderLists() {
  $('lists').innerHTML = lists.map((list) => `
    <article class="list-card">
      <h3>${list.title}</h3>
      <p class="small muted">by ${list.by}</p>
      <ul>${list.items.map((item) => `<li>${item}</li>`).join('')}</ul>
    </article>
  `).join('');
}

function renderSaved() {
  const saved = events.filter((event) => state.saved.includes(event.id));
  $('saved-events').innerHTML = saved.length
    ? saved.map((event) => `<div class="list-card"><strong>${event.title}</strong><p class="small muted">${event.day} · ${event.neighborhood}</p></div>`).join('')
    : 'No saved events yet.';
}

function renderStacks() {
  $('featured-events').innerHTML = events.filter((e) => e.featured).map((event) => `<div class="list-card"><strong>${event.title}</strong><p class="small muted">Featured placement · ${event.neighborhood}</p></div>`).join('');
  $('hidden-gems').innerHTML = events.filter((e) => e.hiddenGem).map((event) => `<div class="list-card"><strong>${event.title}</strong><p class="small muted">Hidden gem · ${event.neighborhood}</p></div>`).join('');
}

function toggleSelection(array, value) {
  return array.includes(value) ? array.filter((v) => v !== value) : [...array, value];
}

function handleNeighborhoodToggle(value) {
  state.prefs.neighborhoods = toggleSelection(state.prefs.neighborhoods, value);
  renderChips('neighborhood-chips', neighborhoods, state.prefs.neighborhoods, handleNeighborhoodToggle);
  renderEvents();
}

function handleVibeToggle(value) {
  state.prefs.vibes = toggleSelection(state.prefs.vibes, value);
  renderChips('vibe-chips', vibes, state.prefs.vibes, handleVibeToggle);
  renderEvents();
}

renderSelectOptions();
renderChips('neighborhood-chips', neighborhoods, state.prefs.neighborhoods, handleNeighborhoodToggle);
renderChips('vibe-chips', vibes, state.prefs.vibes, handleVibeToggle);
renderEvents();
renderLists();
renderSaved();
renderStacks();

$('neighborhood-filter').onchange = (e) => { state.filters.neighborhood = e.target.value; renderEvents(); };
$('vibe-filter').onchange = (e) => { state.filters.vibe = e.target.value; renderEvents(); };
$('free-only').onchange = (e) => { state.filters.freeOnly = e.target.checked; renderEvents(); };
$('reset-filters').onclick = () => {
  state.filters = { neighborhood: '', vibe: '', freeOnly: false };
  $('neighborhood-filter').value = '';
  $('vibe-filter').value = '';
  $('free-only').checked = false;
  renderEvents();
};

$('view-list').onclick = () => {
  state.view = 'list';
  listView.classList.remove('hidden'); mapView.classList.add('hidden');
  $('view-list').classList.add('active'); $('view-map').classList.remove('active');
};
$('view-map').onclick = () => {
  state.view = 'map';
  mapView.classList.remove('hidden'); listView.classList.add('hidden');
  $('view-map').classList.add('active'); $('view-list').classList.remove('active');
};

$('digest-form').onsubmit = (e) => {
  e.preventDefault();
  localStorage.setItem('rva-now-digest-email', $('digest-email').value);
  $('digest-status').textContent = `Saved ${$('digest-email').value} for the RVA weekend digest.`;
  $('digest-form').reset();
};

$('submit-form').onsubmit = (e) => {
  e.preventDefault();
  $('submit-status').textContent = 'Submission captured. Next step: route to organizer inbox + monetization workflow.';
  e.target.reset();
};
