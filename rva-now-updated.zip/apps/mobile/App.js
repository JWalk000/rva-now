import React, { useMemo, useState } from 'react';
import { SafeAreaView, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { events, neighborhoods, vibes } from '../../packages/shared/src/data.js';
import { personalize } from '../../packages/shared/src/helpers.js';

export default function App() {
  const [selectedNeighborhoods, setSelectedNeighborhoods] = useState(["The Fan", "Scott's Addition"]);
  const [selectedVibes, setSelectedVibes] = useState(["Food & Drink", "Live Music"]);

  const feed = useMemo(
    () => personalize(events, { neighborhoods: selectedNeighborhoods, vibes: selectedVibes }).slice(0, 5),
    [selectedNeighborhoods, selectedVibes]
  );

  const toggle = (value, current, setter) => setter(current.includes(value) ? current.filter((x) => x !== value) : [...current, value]);

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.eyebrow}>RVA NOW APP</Text>
        <Text style={styles.title}>Hyperlocal discovery for Richmond</Text>
        <Text style={styles.copy}>Website-first product translated into mobile: personalized feed, neighborhood filters, hidden gems, and organizer-ready growth loops.</Text>

        <Section title="Neighborhoods">
          <ChipRow values={neighborhoods} selected={selectedNeighborhoods} onPress={(value) => toggle(value, selectedNeighborhoods, setSelectedNeighborhoods)} />
        </Section>

        <Section title="Vibes">
          <ChipRow values={vibes} selected={selectedVibes} onPress={(value) => toggle(value, selectedVibes, setSelectedVibes)} />
        </Section>

        <Section title="For You">
          {feed.map((event) => (
            <View key={event.id} style={styles.card}>
              <Text style={styles.cardTitle}>{event.title}</Text>
              <Text style={styles.meta}>{event.day} · {event.time} · {event.neighborhood}</Text>
              <Text style={styles.copy}>{event.description}</Text>
            </View>
          ))}
        </Section>

        <Section title="Monetization lanes">
          {['Featured placements', 'Organizer subscriptions', 'Weekly digest sponsorships'].map((item) => (
            <View key={item} style={styles.card}><Text style={styles.cardTitle}>{item}</Text></View>
          ))}
        </Section>
      </ScrollView>
    </SafeAreaView>
  );
}

function Section({ title, children }) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {children}
    </View>
  );
}

function ChipRow({ values, selected, onPress }) {
  return (
    <View style={styles.rowWrap}>
      {values.map((value) => (
        <TouchableOpacity key={value} onPress={() => onPress(value)} style={[styles.chip, selected.includes(value) && styles.chipActive]}>
          <Text style={styles.chipText}>{value}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#08111d' },
  container: { padding: 20, gap: 16 },
  eyebrow: { color: '#7ef0c3', textTransform: 'uppercase', letterSpacing: 1.5, fontSize: 12 },
  title: { color: '#f2f7ff', fontSize: 30, fontWeight: '800' },
  copy: { color: '#9ab0cc', lineHeight: 20 },
  section: { gap: 12 },
  sectionTitle: { color: '#f2f7ff', fontSize: 20, fontWeight: '700' },
  rowWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: { borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)', paddingHorizontal: 12, paddingVertical: 10, borderRadius: 999 },
  chipActive: { backgroundColor: 'rgba(126,240,195,0.12)', borderColor: 'rgba(126,240,195,0.45)' },
  chipText: { color: '#f2f7ff' },
  card: { backgroundColor: '#12233a', borderWidth: 1, borderColor: 'rgba(255,255,255,0.08)', borderRadius: 18, padding: 16, gap: 8 },
  cardTitle: { color: '#f2f7ff', fontSize: 18, fontWeight: '700' },
  meta: { color: '#81a8ff' }
});
